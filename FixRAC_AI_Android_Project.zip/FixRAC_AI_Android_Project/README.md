# FixRAC AI — Android Project

Version 1.0.12 / V12 prototype packaged as an Android WebView app.

## Build
Open this folder in Android Studio, let Gradle sync, then use Build > Build APK(s) or Build > Generate Signed Bundle / APK.

Application ID: com.fixrac.ai
Target SDK: 35
Min SDK: 23
