package com.fixrac.ai;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    WebView web = findViewById(R.id.web);
    web.setWebViewClient(new WebViewClient());
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    web.loadUrl("file:///android_asset/fixrac.html");
  }
  @Override public void onBackPressed() {
    WebView web = findViewById(R.id.web);
    if (web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
}
